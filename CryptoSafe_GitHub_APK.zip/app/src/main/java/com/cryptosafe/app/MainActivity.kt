package com.cryptosafe.app

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(11, 18, 32)
    private val card = Color.rgb(24, 34, 52)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun showLogin() {
        setContentView(R.layout.activity_main)

        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val login = findViewById<Button>(R.id.loginButton)
        val register = findViewById<Button>(R.id.registerButton)
        val message = findViewById<TextView>(R.id.message)

        login.setOnClickListener {
            val e = email.text.toString().trim()
            val p = password.text.toString()
            if (e.isEmpty() || p.isEmpty()) {
                message.text = "يرجى إدخال البريد الإلكتروني وكلمة المرور."
            } else {
                showHome(e)
            }
        }

        register.setOnClickListener {
            message.text = "إنشاء الحساب الحقيقي سيُضاف لاحقًا مع خادم آمن."
        }
    }

    private fun showHome(email: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 24)
            setBackgroundColor(bg)
        }

        fun label(text: String, size: Float, bold: Boolean = false) =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.WHITE)
                setPadding(0, 8, 0, 8)
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            }

        root.addView(label("CryptoSafe", 30f, true))
        root.addView(label("مرحبًا بك 👋", 22f, true))
        root.addView(label(email, 13f))
        root.addView(label("الرصيد التجريبي", 14f))
        root.addView(label("$10,000.00", 30f, true))
        root.addView(label("الأسواق", 21f, true))

        listOf(
            "Bitcoin (BTC)    $67,500",
            "Ethereum (ETH)   $2,600",
            "Solana (SOL)     $145",
            "SUI (SUI)        $3.20"
        ).forEach { coin ->
            val row = label(coin, 17f)
            row.setBackgroundColor(card)
            root.addView(row, LinearLayout.LayoutParams(-1, 58).apply {
                setMargins(0, 4, 0, 4)
            })
        }

        val logout = Button(this).apply {
            text = "تسجيل الخروج"
            isAllCaps = false
        }
        root.addView(logout, LinearLayout.LayoutParams(-1, 56).apply {
            setMargins(0, 20, 0, 0)
        })
        logout.setOnClickListener { showLogin() }

        root.addView(label("الأسعار تجريبية وليست بيانات سوق مباشرة.", 12f))
        setContentView(root)
    }
}
